using Microsoft.EntityFrameworkCore;
using MisterAutoAndTurbo.Web.Models;
using MisterAutoAndTurbo.Web.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Npgsql;
using MisterAutoAndTurbo.Web.Models;
using MisterAutoAndTurbo.Web.Data;

namespace MisterAutoAndTurbo.Web.Data
{
    /// <summary>
    /// Working copy of the staff app data. It is loaded from the Supabase (PostgreSQL) database when the app starts
    /// and written back to it after every change (see <see cref="PersistChangesFilter"/>).
    /// The sample records below are only inserted the first time, when the database is created.
    /// </summary>
    public static class AppDataStore
    {
        private static readonly object _lock = new();
        private static readonly object _dbLock = new();
        private static int _jobSeq = 3; // after sample job-001..003

        public static List<Vehicle> Vehicles { get; } = new()
        {
            new Vehicle
            {
                Id = "veh-001",
                CustomerId = "cust-001",
                RegistrationNumber = "ABC 123 FS",
                Make = "Toyota",
                Model = "Hilux",
                Year = 2019,
                Mileage = 85400
            },
            new Vehicle
            {
                Id = "veh-002",
                CustomerId = "cust-002",
                RegistrationNumber = "XYZ 456 GP",
                Make = "Volkswagen",
                Model = "Polo",
                Year = 2018,
                Mileage = 67200
            },
            new Vehicle
            {
                Id = "veh-003",
                CustomerId = "cust-003",
                RegistrationNumber = "DEF 789 FS",
                Make = "Ford",
                Model = "Ranger",
                Year = 2021,
                Mileage = 41200
            }
        };

        public static List<Customer> Customers { get; } = new()
        {
            new Customer
            {
                Id = "cust-001",
                Name = "Thabo",
                Surname = "Molefe",
                Phone = "082 111 2233",
                Email = "thabo@example.com",
                Address = "12 Constantia Rd, Welkom"
            },
            new Customer
            {
                Id = "cust-002",
                Name = "Sarah",
                Surname = "Nkosi",
                Phone = "083 444 5566",
                Email = "sarah@example.com",
                Address = "45 Stateway, Welkom"
            },
            new Customer
            {
                Id = "cust-003",
                Name = "Johan",
                Surname = "Botha",
                Phone = "084 777 8899",
                Email = "johan@example.com",
                Address = "8 Dagbreek Ave, Welkom"
            }
        };

        public static List<JobCard> JobCards { get; } = new()
        {
            new JobCard
            {
                Id = "job-001",
                VehichleId = "veh-001",
                CustomerId = "cust-001",
                Status = JobStatus.Quotation,
                Diagnosis = "Turbo lag / boost leak",
                CreatedAt = DateTime.Today.AddDays(-2),
                CreatedById = "staff-01",
                MechanicId = "mech-01"
            },
            new JobCard
            {
                Id = "job-002",
                VehichleId = "veh-002",
                CustomerId = "cust-002",
                Status = JobStatus.Inspection,
                Diagnosis = "Service + brake check",
                CreatedAt = DateTime.Today.AddDays(-1),
                CreatedById = "staff-01"
            },
            new JobCard
            {
                Id = "job-003",
                VehichleId = "veh-003",
                CustomerId = "cust-003",
                Status = JobStatus.ReadyForCollection,
                Diagnosis = "Oil leak under sump",
                CreatedAt = DateTime.Today,
                CreatedById = "staff-01",
                MechanicId = "mech-01"
            }
        };

        public static List<ServiceRequest> ServiceRequests { get; } = new();

        public static List<Quotation> Quotations { get; } = new()
        {
            new Quotation
            {
                Id = "quot-001",
                JobCardId = "job-001",
                CustomerId = "cust-001",
                VehicleId = "veh-001",
                Description = "Diagnose turbo boost leak, replace hose, labour",
                LabourCost = 1200m,
                PartsCost = 850m,
                CustomerSuppliedDifference = 0m,
                TotalCost = 2050m,
                Status = "Pending",
                CreatedAt = DateTime.Today.AddDays(-1)
            },
            new Quotation
            {
                Id = "quot-002",
                JobCardId = "job-002",
                CustomerId = "cust-002",
                VehicleId = "veh-002",
                Description = "Full service + front brake pads",
                LabourCost = 800m,
                PartsCost = 1450m,
                CustomerSuppliedDifference = 200m,
                TotalCost = 2050m,
                Status = "Approved",
                CreatedAt = DateTime.Today
            }
        };



        public static List<Appointment> Appointments { get; } = new()
        {
            new Appointment
            {
                Id = "apt-001",
                CustomerId = "cust-001",
                VehicleId = "veh-001",
                JobCardId = "job-001",
                CreatedById = "staff-01",
                ScheduledAt = DateTime.Today.AddHours(9),
                Status = "Scheduled"
            },
            new Appointment
            {
                Id = "apt-002",
                CustomerId = "cust-002",
                VehicleId = "veh-002",
                CreatedById = "staff-01",
                ScheduledAt = DateTime.Today.AddHours(11),
                Status = "Arrived"
            },
            new Appointment
            {
                Id = "apt-003",
                CustomerId = "cust-003",
                VehicleId = "veh-003",
                CreatedById = "staff-01",
                ScheduledAt = DateTime.Today.AddDays(1).AddHours(10),
                Status = "Scheduled"
            }
        };


        public static List<Part> Parts { get; } = new()
        {
            new Part
            {
                Id = "part-001",
                Name = "Turbo boost hose",
                Category = "Turbo",
                QuantityInStock = 12,
                UnitPrice = 450.00m,
                ReorderLevel = 5
            },
            new Part
            {
                Id = "part-002",
                Name = "Front brake pads (set)",
                Category = "Brakes",
                QuantityInStock = 8,
                UnitPrice = 890.00m,
                ReorderLevel = 4
            },
            new Part
            {
                Id = "part-003",
                Name = "Engine oil 5W-30 5L",
                Category = "Service",
                QuantityInStock = 3,
                UnitPrice = 520.00m,
                ReorderLevel = 6
            },
            new Part
            {
                Id = "part-004",
                Name = "Oil filter standard",
                Category = "Service",
                QuantityInStock = 25,
                UnitPrice = 95.00m,
                ReorderLevel = 10
            },
            new Part
            {
                Id = "part-005",
                Name = "Sump gasket",
                Category = "Engine",
                QuantityInStock = 2,
                UnitPrice = 180.00m,
                ReorderLevel = 3
            }
        };


        public static List<Payment> Payments { get; } = new()
        {
            new Payment
            {
                Id = "pay-001",
                QuotationId = "quot-002",
                CustomerId = "cust-002",
                RecordedById = "staff-01",
                Amount = 1000.00m,
                Method = "EFT",
                Status = "Confirmed",
                PaidAt = DateTime.Today.AddHours(-3),
                ProofOfPaymentUrl = ""
            }
        };


        public static List<VehicleCollection> VehicleCollections { get; } = new()
        {
            new VehicleCollection
            {
                Id = "col-001",
                JobCardId = "job-003",
                CustomerId = "cust-003",
                VehicleId = "veh-003",
                ManagedById = "staff-01",
                CollectionStatus = "Ready",
                ScheduledAt = DateTime.Today.AddHours(15),
                Notes = "Customer notified — Ford Ranger ready"
            }
        };


        public static List<Complaint> Complaints { get; } = new()
        {
            new Complaint
            {
                Id = "cmp-001",
                CustomerId = "cust-001",
                JobCardId = "job-001",
                VehicleId = "veh-001",
                Subject = "Work took longer than quoted",
                Description = "I was told the turbo hose would be done in one day but the car was still not ready after three days.",
                Status = "Open",
                Source = "Mobile",
                CreatedAt = DateTime.Today.AddHours(-5)
            }
        };

        public static List<Notification> Notifications { get; } = new();

        /// <summary>
        /// Staff accounts. Passwords are plain text for this demo in-memory store only.
        /// Roles: Manager (full access), Receptionist, Mechanic (limited per use-case diagrams).
        /// </summary>
        public static List<UserAccount> Users { get; } = new()
        {
            new UserAccount
            {
                Id = "user-mgr-001",
                Username = "manager",
                Email = "manager@misterauto.co.za",
                Phone = "082 000 0001",
                PasswordHash = "Manager@123",
                Role = "Manager",
                CreatedAt = DateTime.UtcNow.AddDays(-30)
            },
            new UserAccount
            {
                Id = "user-rec-001",
                Username = "reception",
                Email = "reception@misterauto.co.za",
                Phone = "082 000 0002",
                PasswordHash = "Reception@123",
                Role = "Receptionist",
                CreatedAt = DateTime.UtcNow.AddDays(-20)
            },
            new UserAccount
            {
                Id = "user-mec-001",
                Username = "mechanic",
                Email = "mechanic@misterauto.co.za",
                Phone = "082 000 0003",
                PasswordHash = "Mechanic@123",
                Role = "Mechanic",
                CreatedAt = DateTime.UtcNow.AddDays(-10)
            }
        };

        /// <summary>Business details and payment settings edited on the Settings page.</summary>
        public static BusinessSettings Settings { get; } = new();

        // ------------------------------------------------------------------
        // Database persistence
        // ------------------------------------------------------------------

        /// <summary>Replace the in-memory lists with whatever is saved in the database.</summary>
        /// <summary>Called once at startup: create tables if needed, seed sample data on first run, otherwise load saved data.</summary>
        /// <summary>Called once at startup: create tables if needed, seed sample data on first run, otherwise load saved data.</summary>
        public static void Initialize(ApplicationDbContext db)
        {
            // EnsureCreated() does nothing on Supabase because the database already contains
            // Supabase's own tables, so create this app's tables explicitly.
            var creator = db.GetService<IRelationalDatabaseCreator>();
            try
            {
                creator.CreateTables();
            }
            catch (PostgresException ex) when (ex.SqlState == "42P07")
            {
                // 42P07 = tables already exist (normal on every start after the first).
            }

            if (db.UserAccounts.Any())
                LoadFromDatabase(db);
            else
                SaveToDatabase(db);   // first run: store the built-in sample data
        }

        public static void LoadFromDatabase(ApplicationDbContext db)
        {
            lock (_dbLock)
            {
                Replace(Vehicles, db.Vehicles);
                Replace(Customers, db.Customers);
                Replace(JobCards, db.JobCards);
                Replace(ServiceRequests, db.ServiceRequests);
                Replace(Quotations, db.Quotations);
                Replace(Appointments, db.Appointments);
                Replace(Parts, db.Parts);
                Replace(Payments, db.Payments);
                Replace(VehicleCollections, db.VehicleCollections);
                Replace(Complaints, db.Complaints);
                Replace(Notifications, db.Notifications);
                Replace(Users, db.UserAccounts);

                var saved = db.BusinessSettings.AsNoTracking().FirstOrDefault();
                if (saved != null)
                {
                    Settings.BusinessName = saved.BusinessName;
                    Settings.VatNumber = saved.VatNumber;
                    Settings.Address = saved.Address;
                    Settings.Currency = saved.Currency;
                    Settings.VatRate = saved.VatRate;
                }

                // Continue job numbering after the highest saved job-NNN.
                _jobSeq = JobCards
                    .Select(j => j.Id.StartsWith("job-") && int.TryParse(j.Id[4..], out var n) ? n : 0)
                    .DefaultIfEmpty(0)
                    .Max();
            }
        }

        /// <summary>Write the in-memory lists to the database (insert new, update changed, delete removed).</summary>
        public static void SaveToDatabase(ApplicationDbContext db)
        {
            lock (_dbLock)
            {
                Sync(db, db.Vehicles, Vehicles);
                Sync(db, db.Customers, Customers);
                Sync(db, db.JobCards, JobCards);
                Sync(db, db.ServiceRequests, ServiceRequests);
                Sync(db, db.Quotations, Quotations);
                Sync(db, db.Appointments, Appointments);
                Sync(db, db.Parts, Parts);
                Sync(db, db.Payments, Payments);
                Sync(db, db.VehicleCollections, VehicleCollections);
                Sync(db, db.Complaints, Complaints);
                Sync(db, db.Notifications, Notifications);
                Sync(db, db.UserAccounts, Users);

                Settings.Id = 1;
                var row = db.BusinessSettings.FirstOrDefault();
                if (row == null)
                    db.BusinessSettings.Add(new BusinessSettings
                    {
                        Id = 1,
                        BusinessName = Settings.BusinessName,
                        VatNumber = Settings.VatNumber,
                        Address = Settings.Address,
                        Currency = Settings.Currency,
                        VatRate = Settings.VatRate
                    });
                else
                    db.Entry(row).CurrentValues.SetValues(Settings);

                db.SaveChanges();
            }
        }

        private static void Replace<T>(List<T> list, IQueryable<T> query) where T : class
        {
            var items = query.AsNoTracking().ToList();
            list.Clear();
            list.AddRange(items);
        }

        private static void Sync<T>(ApplicationDbContext db, DbSet<T> set, List<T> items) where T : class
        {
            var key = db.Model.FindEntityType(typeof(T))!.FindPrimaryKey()!.Properties[0].PropertyInfo!;
            var saved = set.ToList().ToDictionary(e => (string)key.GetValue(e)!);
            var seen = new HashSet<string>();

            foreach (var item in items.ToList())
            {
                var id = (string)key.GetValue(item)!;
                if (!seen.Add(id)) continue;

                if (saved.TryGetValue(id, out var row))
                    db.Entry(row).CurrentValues.SetValues(item);   // only changed columns are updated
                else
                    set.Add(item);
            }

            foreach (var kv in saved)
                if (!seen.Contains(kv.Key))
                    set.Remove(kv.Value);
        }

        public static string NewId(string prefix)
        {
            lock (_lock)
            {
                return $"{prefix}-{Guid.NewGuid().ToString("N")[..8]}";
            }
        }

        /// <summary>Sequential job id: job-004, job-005, ...</summary>
        public static string NextJobCardId()
        {
            lock (_lock)
            {
                _jobSeq++;
                return $"job-{_jobSeq:D3}";
            }
        }
    }
}
