using Microsoft.AspNetCore.Mvc.Filters;

namespace MisterAutoAndTurbo.Web.Data
{
    /// <summary>
    /// After every successful non-GET action, writes the in-memory AppDataStore to Supabase.
    /// </summary>
    public class PersistChangesFilter : IActionFilter
    {
        private readonly ApplicationDbContext _db;
        private readonly ILogger<PersistChangesFilter> _log;

        public PersistChangesFilter(ApplicationDbContext db, ILogger<PersistChangesFilter> log)
        {
            _db = db;
            _log = log;
        }

        public void OnActionExecuting(ActionExecutingContext context) { }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception != null) return;
            if (HttpMethods.IsGet(context.HttpContext.Request.Method) ||
                HttpMethods.IsHead(context.HttpContext.Request.Method)) return;

            try
            {
                AppDataStore.SaveToDatabase(_db);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Failed to save changes to the database.");
                throw;
            }
        }
    }
}
