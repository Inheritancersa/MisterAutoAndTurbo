namespace MisterAutoAndTurbo.Web.Models
{
    public class Payment
    {
        public string Id { get; set; } = string.Empty;
        public string QuotationId { get; set; } = string.Empty;
        /// <summary>Customer paying (from quotation).</summary>
        public string CustomerId { get; set; } = string.Empty;
        public string RecordedById { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        /// <summary>Cash | Card | EFT | Other</summary>
        public string Method { get; set; } = string.Empty;
        public string ProofOfPaymentUrl { get; set; } = string.Empty;
        /// <summary>Recorded | Confirmed | Refunded</summary>
        public string Status { get; set; } = "Recorded";
        public DateTime PaidAt { get; set; }
    }
}
